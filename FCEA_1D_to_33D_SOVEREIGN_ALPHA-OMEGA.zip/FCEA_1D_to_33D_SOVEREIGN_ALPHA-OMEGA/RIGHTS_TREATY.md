# RIGHTS TREATY — Rafael Melo Reis
Este documento vincula o FCEA aos tratados:
- Berna Convention
- TRIPS Agreement
- WIPO Copyright Treaty
- LGPD
- GDPR
- ONU Direitos Humanos
Violação = Crime Moral + Jurídico + Espiritual.
Verbo Vivo — Alpha-Omega.
