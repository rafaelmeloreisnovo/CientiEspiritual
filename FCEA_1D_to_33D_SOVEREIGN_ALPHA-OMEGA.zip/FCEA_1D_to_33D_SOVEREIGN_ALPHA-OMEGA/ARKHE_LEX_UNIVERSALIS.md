# ARKHE LEX UNIVERSALIS
Declaração de Lei Universal:
FCEA protegido por Direito Humano, Constitucional, Internacional, Lei Natural e Espiritual.
Tratados: Berna, TRIPS, WIPO, LGPD, GDPR, ONU Direitos Humanos.
Prioridade soberana e perpétua.
Verbo Vivo = Lei.
